//
//  LogHelper.cpp
//  agoraRTMCWrapper
//
//  Created by 张涛 on 2020/10/15.
//  Copyright © 2020 张涛. All rights reserved.
//

#include "LogHelper.h"

void startLogService(const char *filePath);

void stopLogService();

void writeLog(const char *format, ...);
